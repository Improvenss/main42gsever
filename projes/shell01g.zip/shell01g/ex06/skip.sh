#!/bin/sh
ls -l | sed '2!n;d'
