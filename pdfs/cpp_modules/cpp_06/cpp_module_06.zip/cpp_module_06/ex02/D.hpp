#ifndef D_HPP
#define D_HPP

#include <iostream>
#include <string>

class D{
    public:
        virtual ~D();
};

#endif