
#ifndef BASE_HPP
#define BASE_HPP

#include <string>
#include <iostream>
#include <cstdlib>

class Base{
    public:
        virtual ~Base();
};

#endif