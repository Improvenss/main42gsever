#include "D.hpp"

D::~D(){
    std::cout<<"D is dying"<<std::endl;
}